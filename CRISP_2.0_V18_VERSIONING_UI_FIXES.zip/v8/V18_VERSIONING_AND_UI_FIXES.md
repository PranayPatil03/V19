# CRISP_2.0 V18 – Versioning, framework values, rules and UI fixes

## Changes

- Parameter, rule and validation edit forms track the original stable key. Editing a cloned DTO no longer triggers a false duplicate warning.
- Parameter codes are locked while editing an existing parameter so saved framework values remain associated with the same identity.
- Framework retrieval uses the selected version's JSON definition. Parameter sets can differ between versions; matching values are retained by stable code/name/legacy ID and newly added parameters start blank.
- When a framework/version has no JSON value snapshot yet, the application performs a one-time compatibility seed from existing framework values, saves the snapshot for that version, and retrieves it. It does not keep falling back to live relational values on every retrieval.
- Parameter definitions, rules and validations used during evaluation come from the selected immutable workflow JSON, not the current master tables.
- The Rules Engine uses the `WorkflowName` stored inside the selected JSON, rather than assuming it is the database workflow code. This fixes the `Rule config file is not present for the CorporateBusiness workflow` error when code and JSON workflow name differ.
- Replaced the appended V14/V17 CSS override blocks with one formatted, consolidated section for toolbar, version selector, underline-style framework inputs, and score dialog layout. Existing application shell and sidebar styles remain intact.
- No EF migrations were added. The existing database schema is retained.

## Versioning behavior

- Saving a master definition creates a new Draft JSON version.
- Publishing creates a published version and archives prior published versions.
- The framework defaults to the latest published version.
- Selecting a different version and clicking Retrieve loads that version's JSON and its saved value snapshot. If that version has never had a value snapshot, matching values are copied once from the framework's existing values; new parameters remain blank.
- Values saved for one version are stored under that framework ID and version number and do not overwrite another version's snapshot.

## Test checklist

1. Open Parameters and edit an existing parameter without changing its code; save. It should not report that the code already exists.
2. Edit an existing Rule and Validation; save. It should update the selected definition and create a new Draft version without duplicate warnings.
3. Publish the new JSON. Confirm the latest version says Published and previous published versions are Archived.
4. Open an existing framework. Confirm latest Published is selected by default.
5. Select an older version and click Retrieve. Confirm its parameter set appears, matching values are loaded, and parameters added later do not appear.
6. Run Framework. Confirm it executes the `WorkflowName` in the selected JSON.
7. Check desktop and mobile layouts for toolbar wrapping and score-dialog horizontal scrolling.

## Build note

This environment does not have the .NET SDK installed, so a full `dotnet build` could not be run here. Build the solution in Visual Studio and run the checklist before IIS deployment.
